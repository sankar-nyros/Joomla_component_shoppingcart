<?php
/*------------------------------------------------------------------------
 # com_j2store - J2Store
# ------------------------------------------------------------------------
# author    Ramesh Elamathi - Weblogicx India http://www.weblogicxindia.com
# copyright Copyright (C) 2014-19 Weblogicxindia.com. All Rights Reserved.
# @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: http://j2store.org
-------------------------------------------------------------------------*/

// No direct access to this file
defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.controllerform');

class J2StoreControllerCoupon extends JControllerForm

{
	function __construct($config = array())
	{
		parent::__construct($config);
	}

	function save() {
	
		$app = JFactory::getApplication ();
		
		$name = $app->input->getString ('cpn_name');
		$disc = $app->input->getString ('cpn_disc');
		$code = $app->input->getString ('cpn_code');
		$from = $app->input->getString ('dp_from');
		$to = $app->input->getString ('dp_to');

		$db = JFactory::getDbo();
			
		$query = $db->getQuery(true);
		$from = date('Y-m-d',strtotime($from));
		$to = date('Y-m-d',strtotime($to));
	    
	    $query = "INSERT INTO `#__j2store_promocodes`(`name`,`discount`,`code`,`from`,`to`) VALUES('".$name."','".$disc."','".$code."','".$from."','".$to."')";
		$db->setQuery($query);
		$db->query();
		$link = 'index.php?option=com_j2store&view=coupons';
		$msg = "Coupon created successfully.";
	    
		
		$this->setRedirect($link, $msg);
					
	}
	
	
	function update() {
	
		$app = JFactory::getApplication ();
		
		$id = $app->input->getString ('cpn_id');
		$name = $app->input->getString ('cpn_name');
		$disc = $app->input->getString ('cpn_disc');
		$code = $app->input->getString ('cpn_code');
		$from = $app->input->getString ('dp_from');
		$to = $app->input->getString ('dp_to');

		$db = JFactory::getDbo();
			
		$query = $db->getQuery(true);
		$from = date('Y-m-d',strtotime($from));
		$to = date('Y-m-d',strtotime($to));
	    
	    $query = "UPDATE `#__j2store_promocodes` SET `name` = '$name',`discount` = '$disc',`code` = '$code' ,`from` = '$from',`to` = '$to' where `promocode_id` = $id";
		$db->setQuery($query);
		$db->query();
		$link = 'index.php?option=com_j2store&view=coupons';
		$msg = "Coupon updated successfully.";
	    
		
		$this->setRedirect($link, $msg);
					
	}

	function checkduplicate()
	{
		
		$code = $_POST['code'];
		$db = JFactory::getDbo();	
		$query = "select * from `#__j2store_promocodes` where code = '".$code."'";
		
		$db->setQuery($query);
		$result = $db->loadObjectList(); 
		if(count($result) > 0)
		{
			echo json_encode(array('result'=>1));	
  		    exit;
		}
		else
		{
			echo json_encode(array('result'=>0));
			exit;	
		}
	}



}
