<?php
/*------------------------------------------------------------------------
 # com_j2store - J2Store
# ------------------------------------------------------------------------
# author    Ramesh Elamathi - Weblogicx India http://www.weblogicxindia.com
# copyright Copyright (C) 2014 - 19 Weblogicxindia.com. All Rights Reserved.
# @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: http://j2store.org
-------------------------------------------------------------------------*/
// No direct access to this file
defined('_JEXEC') or die('Restricted access');

// import Joomla controllerform library
jimport('joomla.application.component.controllerform');
JTable::addIncludePath(JPATH_ADMINISTRATOR.'/components/com_j2store/tables');




class J2StoreControllerEnquries extends J2StoreController
{

	function __construct($config = array())
	{
		parent::__construct($config);
		
	}
	
	function enquiry()
	{
		$app = JFactory::getApplication();
		$id = $app->input->getInt('ids', 0);
		$comments = $app->input->getString('comments', 0);
		$usermail = $app->input->getString('email', 0);
		$eid = $app->input->getString('eid', 0);
	

		$db = JFactory::getDbo();
		$query = $db->getQuery(true);
		
		$query = "UPDATE `#__j2store_orderenquiry` SET `review`=1, `request`=1 where id =".$eid;
		
		$db->setQuery($query);
	    $db->query();
		
		
		$mailer = JFactory::getMailer();
		$config = JFactory::getConfig();
		$sender = array($config->get( 'mailfrom' ),$config->get( 'fromname' ) );
 		$mailer->setSender($sender);
 		$mailer->addRecipient($usermail);
 
		$mailer->setSubject('[MobiWorld]Order Enquiry');
		$mailer->setBody($body);
		// Optional file attached
		//$mailer->addAttachment(JPATH_COMPONENT.'/assets/document.pdf');

	
		$body   = '<h2>Order Enquiry</h2>'
			. '<div>'.$comments.'</div><br><br>Regards,<br>MobiWorld,<br>Support Team.';
		$mailer->isHTML(true);
		$mailer->Encoding = 'base64';
		$mailer->setBody($body);
		// Optionally add embedded image
		//$mailer->AddEmbeddedImage( JPATH_COMPONENT.'/assets/logo128.jpg', 'logo_id', 'logo.jpg', 'base64', 'image/jpeg' );

		
		

		$send = $mailer->Send();
		if ( $send !== true ) {
			$msg =  "Error sending email: " . $send->__toString();
		} else {
			 $msg = "Order satus sent to user successfully...!";
		}

		$link = 'index.php?option=com_j2store&view=enquries';
       
		$this->setRedirect($link, $msg);
	}
	
	
	function deleteenquiry()
	{
		$app = JFactory::getApplication();
		$delids = $app->input->getString('allids', 0);
	
		$delids = rtrim($delids, ",");
	
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);
		
		$query = "Delete from `#__j2store_orderenquiry` WHERE id IN ($delids)";
		$db->setQuery($query);
	    $res = $db->query();

		if($res == 1)
		{
			$msg = 'Deleted item(s)';
		}
		else
		{
			$msg='Selected Item(s) not deleted';
		}
		
		$link = 'index.php?option=com_j2store&view=enquries';
		$this->setRedirect($link, $msg);
	}
}
