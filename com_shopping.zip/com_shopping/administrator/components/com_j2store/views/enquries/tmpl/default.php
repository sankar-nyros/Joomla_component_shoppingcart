<?php
/*------------------------------------------------------------------------
 # com_j2store - J2Store
# ------------------------------------------------------------------------
# author    Ramesh Elamathi - Weblogicx India http://www.weblogicxindia.com
# copyright Copyright (C) 2014 - 19 Weblogicxindia.com. All Rights Reserved.
# @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: http://j2store.org
-------------------------------------------------------------------------*/
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
?>

<script src="<?php echo JUri::base().'components/com_j2store/views/enquries/tmpl/j2store.js'; ?>"></script>

<div class="j2store">
<h3><?php echo JText::_('J2STORE_ENQURIES');?></h3>
<?php $enqdel_link = JRoute::_('index.php?option=com_j2store&view=enquries&task=deleteenquiry'); ?>
<div class="row-fluid">
	<div class="span12">
		<div class="btn-toolbar" id="toolbar">
			<div class="btn-group" id="toolbar-back">
				<button class="btn btn-small" style="margin-top:-18px;" onclick="location.href='javascript:history.back();'; ">
					<span class="icon-back"></span>
					Back
				</button>
			</div>

			<div class="btn-group" id="toolbar-delete">
				<form method="post" action="<?php echo $enqdel_link ; ?>">
				<button type="submit" onclick="return delvalid()" class="btn btn-small"><span class="icon-delete "></span> Delete</button>
				<input type="hidden" id="allids" name="allids">
				</form>
			</div>
		</div>
	</div>
</div>


<?php
	
	if(isset($_GET["limit"]))
	{
		$limit = $_GET["limit"];
	}
	else
	{
		$limit = 5;
	}
	
	if(isset($_GET["page_no"]))
	{
		$page = $_GET["page_no"];
   		$start_limit = ($page * $limit) - $limit; 
	 	$end_limit= $limit;
	}
	else
	{
		$start_limit = 0;
		$end_limit = $limit;
	}
?>

<script>
    
	jQuery(document).ready(function() {
		var query = window.location.search.substring(1);  //get the url parameters
		var vars = query.split("&");		
		for (var i = 0; i < vars.length; i++) {
		    var pair = vars[i].split("=");
		    if (pair[0] == 'limit') {
		        jQuery('#pagelimit').val(pair[1]);
		    }
		}
	});
	
	function paginate()
	{
		pagelimit = jQuery('#pagelimit').val();
		location.href="index.php?option=com_j2store&view=enquries&page_no=1&limit="+pagelimit;
	}
</script>

<?php echo $msg; ?>
<?php $enquiry_link = JRoute::_('index.php?option=com_j2store&view=enquries&task=enquiry'); ?>
<?php 

	  $query="SELECT `#__j2store_orders`.*,  `#__j2store_orderenquiry`.* FROM `#__j2store_orders` INNER JOIN `#__j2store_orderenquiry` ON `#__j2store_orders`.id= `#__j2store_orderenquiry`.invoice order by `#__j2store_orderenquiry`.id desc limit $start_limit,$end_limit";
			
	  $db = &JFactory::getDBO();
	  $db->setQuery($query);
	  $result = $db->loadObjectList(); 

?>

	<table class="adminlist table table-striped table-hover">
		<thead>
			<tr>
				<th width="1%">No.</th>
				<th width="1%"><input type="checkbox" id="selcbx"></th>
				<th width="3%">OrderDate</th>
				<th width="1%">Invoice</th>
				<th width="3%">Enquiry Date</th>
				<th width="1%">Comments</th>
				<th width="2%">Action</th>
			</tr>
		</thead>
		<tfoot>
			<tr>
				<td colspan="7">
				<div style="float:left;">
				<?php 
				include("paginatefunction.php");
				
				echo pagination('#__j2store_orderenquiry',$limit,$page); ?>
				</div>
				<div style="float:left;margin-left:10px;">
				<select style="width:60px;height:32px;" id="pagelimit" onchange="paginate()">
					<option value="5">5</option>
					<option value="10">10</option>
					<option value="20">20</option>
					<option value="50">50</option>
					<option value="100">100</option>
				</select>
				</div>
				</td>
			</tr>
		</tfoot>
		<tbody>	
			<?php
			$i =1;
			foreach($result as $row)
			{
			?>	
			<tr>
				<form action ="<?php echo $enquiry_link ; ?>"  method="post" name="enquiryForm">
				<td><?php echo $i; ?><?php if($row->review == 0){ ; ?> <i class="icon-star-empty"></i> <?php } else { ?>
					 <i class="icon-star"></i> <?php } ?>
				</td>
				<td><input type="checkbox" class="cbx" data-val="<?php echo $row->id; ?>"></td>
				<td><?php echo $row->created_date; ?></td>
				<td><a href="index.php?option=com_j2store&view=orders&task=view&id=19"><?php echo $row->invoice; ?></a></td>
				<td><?php echo $row->date; ?></td>
				<td>
					<textarea id="comments" name="comments" title="Please enter comments.." required placeholder="Please enter comments.." style="width:330px;height:50px;"></textarea>
				</td>
				<td>
				    <input type="hidden" name="ids" value="<?php echo $row->invoice; ?>" />
				    <input type="hidden" name="eid" value="<?php echo $row->id; ?>" />
				    <input type="hidden" name="email" value="<?php echo $row->user_email; ?>" />
				    <?php if($row->review == 0) { ; ?>
					<input class="btn btn-primary" type="submit" value="Submit" />
					<?php } else
					{ ?>
					<input class="btn btn-primary" type="submit" value="Submitted" disabled/>
					<?php } ?>
				</form>
				</td>
			</tr>
			<?php  $i++; } ?>
		</tbody>
	</table>
</div>
<link rel="stylesheet" media="screen" href="components/com_j2store/views/enquries/tmpl/pagination.css" />
