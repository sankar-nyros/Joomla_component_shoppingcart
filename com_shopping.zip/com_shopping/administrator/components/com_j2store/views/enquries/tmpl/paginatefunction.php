<?php

/**
* @link: http://www.Awcore.com/dev
*
* changed by serge.kononoff@gmail.com
*/

	function pagination($query, $per_page, $pageNo=1, $url = '?'){  
		
		$whr = "1";
		$limit = $per_page;

		$tmp_url=$tmp_url="option=com_j2store&view=enquries&";
                
		$query = "SELECT COUNT(*) as `num` FROM `$query`";

        $db = &JFactory::getDBO();
        $db->setQuery($query);
        $result =  $db->loadObjectList(); 
       
 		$total = $result[0]->num;

		//$total=$num;
		$adjacents = "2"; 

		 $pageNo = ($pageNo == 0 ? 1 : $pageNo); 
		 $start = (($pageNo - 1) * $per_page);
		 $prev = $pageNo - 1;
		 $next = $pageNo + 1;
		 $lastpage = ceil($total/$per_page);
		 $lpm1 = $lastpage - 1;

		$pagination = "";
		if($lastpage > 1)
		{
			$pagination .= "<ul class='pagination'>";
					//$pagination .= "<li class='details'>Page $pageNo of $lastpage</li>";
					if($pageNo!=1 && $pageNo!=0)
					{
					$firstpage=1;
					$prev = $pageNo - 1;
					$pagination .= "<li><a href='{$url}" . $tmp_url . "page_no=$firstpage&limit=$limit'>First</a></li>";
					$pagination .= "<li><a href='{$url}" . $tmp_url . "page_no=$prev&limit=$limit'>Prev</a></li>";
					
					}
			if ($lastpage < 7 + ($adjacents * 2))
			{	
				for ($counter = 1; $counter <= $lastpage; $counter++)
				{
					if ($counter == $pageNo)
						$pagination.= "<li><a class='current'>$counter</a></li>";
					else
						$pagination.= "<li><a href='{$url}" . $tmp_url . "page_no=$counter&limit=$limit'>$counter</a></li>";
				}
			}
			elseif($lastpage > 5 + ($adjacents * 2))
			{
				if($pageNo < 1 + ($adjacents * 2))		
				{
					for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
					{
						if ($counter == $pageNo)
							$pagination.= "<li><a class='current'>$counter</a></li>";
						else
							$pagination.= "<li><a href='{$url}" . $tmp_url . "page_no=$counter&limit=$limit'>$counter</a></li>";		
					}
					$pagination.= "<li class='dot'>...</li>";
					$pagination.= "<li><a href='{$url}" . $tmp_url . "page_no=$lpm1&limit=$limit'>$lpm1</a></li>";
					$pagination.= "<li><a href='{$url}" . $tmp_url . "page_no=$lastpage&limit=$limit'>$lastpage</a></li>";		
				}
				elseif($lastpage - ($adjacents * 2) > $pageNo && $pageNo > ($adjacents * 2))
				{
					$pagination.= "<li><a href='{$url}" . $tmp_url . "page_no=1&limit=$limit'>1</a></li>";
					$pagination.= "<li><a href='{$url}" . $tmp_url . "page_no=2&limit=$limit'>2</a></li>";
					$pagination.= "<li class='dot'>...</li>";
					for ($counter = $pageNo - $adjacents; $counter <= $pageNo + $adjacents; $counter++)
					{
						if ($counter == $pageNo)
							$pagination.= "<li><a class='current'>$counter</a></li>";
						else
							$pagination.= "<li><a href='{$url}" . $tmp_url . "page_no=$counter&limit=$limit'>$counter</a></li>";	
					}
					$pagination.= "<li class='dot'>..</li>";
					$pagination.= "<li><a href='{$url}" . $tmp_url . "page_no=$lpm1&limit=$limit'>$lpm1</a></li>";
					$pagination.= "<li><a href='{$url}" . $tmp_url . "page_no=$lastpage&limit=$limit'>$lastpage</a></li>";		
				}
				else
				{
					$pagination.= "<li><a href='{$url}" . $tmp_url . "page_no=1&limit=$limit'>1</a></li>";
					$pagination.= "<li><a href='{$url}" . $tmp_url . "page_no=2&limit=$limit'>2</a></li>";
					$pagination.= "<li class='dot'>..</li>";
					for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
					{
						if ($counter == $pageNo)
							$pagination.= "<li><a class='current'>$counter</a></li>";
						else
							$pagination.= "<li><a href='{$url}" . $tmp_url . "page_no=$counter&limit=$limit'>$counter</a></li>";		
					}
				}
			}
			
			if ($pageNo < $counter - 1){ 
				$pagination.= "<li><a href='{$url}" . $tmp_url . "page_no=$next&limit=$limit'>Next</a></li>";
				$pagination.= "<li><a href='{$url}" . $tmp_url . "page_no=$lastpage&limit=$limit'>Last</a></li>";
			}else{
				$pagination.= "<li><a class='current'>Next</a></li>";
				$pagination.= "<li><a class='current'>Last</a></li>";
			}
			$pagination.= "</ul>\n";		
		}
		return $pagination;
	} 
?>
