<?php
/*------------------------------------------------------------------------
 # com_j2store - J2Store
# ------------------------------------------------------------------------
# author    Ramesh Elamathi - Weblogicx India http://www.weblogicxindia.com
# copyright Copyright (C) 2014 - 19 Weblogicxindia.com. All Rights Reserved.
# @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: http://j2store.org
-------------------------------------------------------------------------*/
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
?>
<div class="j2store">
<h3><?php echo JText::_('J2STORE_COUPONS');?></h3>
<!--
<div class="alert alert-block">
	<a class="link purple" target="_blank" href="http://j2store.org/download.html">
		<?php echo JText::_('J2STORE_PRO_VERSION_ONLY');?>
	</a>
</div>
-->
	
	<!-- Start nav bar-->
	
	<div class="span12">
		<div class="btn-toolbar" id="toolbar">
			<div class="btn-group" id="toolbar-back">
				<button class="btn btn-small" onclick="location.href='javascript:history.back();';">
					<span class="icon-back"></span>
					Back
				</button>
			</div>

			<div class="btn-group divider"></div>

			<div class="btn-group" id="toolbar-new">
				<a href="/administrator/index.php?option=com_j2store&view=coupons&task=add"  class="btn btn-small btn-success">
					<i class="icon-new icon-white">
					</i>
					New
				</a>
			</div>

			<div class="btn-group divider"></div>

			<div class="btn-group" id="toolbar-edit">
				<button href="#" onclick="" class="btn btn-small">
				<i class="icon-edit ">
				</i>
				Edit
				</button>
			</div>

			<div class="btn-group divider"></div>
			<?php $coupnsdel_link= JRoute::_('index.php?option=com_j2store&view=coupons&task=deletecoupon'); ?>
			<div class="btn-group" id="toolbar-trash" style="top: 8px;">
				<form method="post" action="<?php echo $coupnsdel_link ; ?>">
					<button type="submit" href="#" onclick="return delvalid()" class="btn btn-small">
					<i class="icon-trash "></i>Trash</button>
				    <input type="hidden" id="allids" name="allids">
				</form>
			</div>
		</div>
	</div>
	<!-- End of nav bar-->

	
	
	<?php 

	  $query="SELECT * FROM `#__j2store_promocodes` order by `promocode_id` desc";
			
	  $db = &JFactory::getDBO();
	  $db->setQuery($query);
	  $result = $db->loadObjectList(); 

?>

	<table class="adminlist table table-striped table-hover">
		<thead>
			<tr>
				<th width="1%">No.</th>
				<th width="1%"><input type="checkbox" id="selcbx"></th>
				<th width="1%">Coupon</th>
				<th width="1%">Value</th>
				<th width="1%">Discount</th>
				<th width="1%">Valid From</th>
				<th width="1%">Valid To</th>
			</tr>
		</thead>
		<tfoot>
		</tfoot>
		<tbody>	
			<?php
			$i =1;
			foreach($result as $row)
			{
			?>	
			<tr>
				<form action ="<?php echo $enquiry_link ; ?>"  method="post" name="enquiryForm">
				<td><?php echo $i; ?></td>
				<td><input type="checkbox" class="cbx" data-val="<?php echo $row->promocode_id; ?>"></td>
				<td><?php echo $row->name; ?></td>
				<td><?php echo $row->code; ?></td>
				<td><?php echo $row->discount; ?></td>
				<td><?php echo $row->from; ?></td>
				<td><?php echo $row->to; ?></td>
				</form>
			</tr>
			<?php  $i++; } ?>
		</tbody>
	</table>


</div>
<script>
jQuery(document).ready(function() {
	jQuery('.cbx').click(function(){
		var id = jQuery(this).attr('data-val');	
		if(jQuery(this).prop('checked') == true)
		{
			jQuery('#allids').val(jQuery('#allids').val()+id+',');
		}
		else
		{
			var checkedid=jQuery('#allids').val();
			var uncheckedid=id+',';
			var rescheck=checkedid.replace(uncheckedid,'');
			jQuery('#allids').val(rescheck);
		}
	});
	
	jQuery('#selcbx').click(function(){
	
		allids = '';
		jQuery('.cbx').each(function(){
			if(jQuery('#selcbx').prop('checked') == true)
			{
				jQuery(this).prop('checked',true);
				allids = allids+jQuery(this).attr('data-val')+',';
			}
			else
			{
				jQuery(this).prop('checked',false);
			}
		});
		
		jQuery('#allids').val(allids);
	
	});
});

function delvalid(){

	if(jQuery('#allids').val().trim().length > 0)
	{
		return true;
	}
	else
	{
		alert('Please first make a selection from the list');
		return false;
	}
}
</script>
