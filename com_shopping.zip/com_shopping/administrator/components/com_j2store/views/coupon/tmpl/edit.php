<?php
/*------------------------------------------------------------------------
 # com_j2store - J2Store
# ------------------------------------------------------------------------
# author    Sasi varna kumar - Weblogicx India http://www.weblogicxindia.com
# copyright Copyright (C) 2014 - 19 Weblogicxindia.com. All Rights Reserved.
# @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: http://j2store.org
# Technical Support:  Forum - http://j2store.org/forum/index.html
-------------------------------------------------------------------------*/

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

$action = JRoute::_('index.php?option=com_j2store&view=coupon');
?>

<div class="j2store">

	<div class="span12">
		<div class="btn-toolbar" id="toolbar">
			<div class="btn-group" id="toolbar-apply">
				<button href="#" id="btn_save" class="btn btn-small btn-success">
				<i class="icon-apply icon-white">
				</i>
				Save
				</button>
			</div>

			<div class="btn-group" id="toolbar-save">
				<button href="#" onclick="" class="btn btn-small">
				<i class="icon-save ">
				</i>
				Save &amp; Close
				</button>
			</div>

			<div class="btn-group" id="toolbar-cancel">
				<button href="#" onclick="" class="btn btn-small">
				<i class="icon-cancel ">
				</i>
				Cancel
				</button>
			</div>
		</div>
	</div>

<?php $cpn_save_link = JRoute::_('index.php?option=com_j2store&view=coupon&task=save'); ?>

<form action="<?php echo $cpn_save_link; ?>" method="post" id="cpn_new">

	
		Coupon Name
		<input type="text" id="cpn_name" name="cpn_name" placeholder="Name" style="margin-left: 29px;margin-top: 20px;">
		<br>
	  
		Coupon Discount
		<input type="text" id="cpn_disc" name="cpn_disc" placeholder="Discount" style="margin-left: 13px;margin-top: 20px;">
		<br>
		
		Coupon code
		<input type="text" id="cpn_code" name="cpn_code" placeholder="Code" style="margin-left: 35px;margin-top: 20px;">
		
		
		
		<br>
		Valid From <input type="text" id="dp_from" name="dp_from" placeholder="valid from" style="margin-left: 50px;margin-top: 20px;">

		<br>
		Valid To <input type="text" id="dp_to" name="dp_to" placeholder="valid to" style="margin-left: 65px;margin-top: 20px;">

</form>
</div>

 <script>
jQuery(function() {

		jQuery( "#dp_from , #dp_to"  ).datepicker({
		 dateFormat: "yy-m-d" 
		});

	jQuery('#btn_save').click(function(){
		
		jQuery('#cpn_new').submit();

	});

});


</script>
