<?php
/*------------------------------------------------------------------------
 # com_j2store - J2Store
# ------------------------------------------------------------------------
# author    Sasi varna kumar - Weblogicx India http://www.weblogicxindia.com
# copyright Copyright (C) 2014 - 19 Weblogicxindia.com. All Rights Reserved.
# @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: http://j2store.org
# Technical Support:  Forum - http://j2store.org/forum/index.html
-------------------------------------------------------------------------*/

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

$action = JRoute::_('index.php?option=com_j2store&view=coupon');
?>

<div class="j2store">

	<div class="span12">
		<div class="btn-toolbar" id="toolbar">
			<?php if(!isset($_REQUEST['id'])) {  ?>
			<div class="btn-group" id="toolbar-apply">
				<button href="#" id="btn_save"  data-action="save" class="btn btn-small btn-success save">
				<i class="icon-apply icon-white">
				</i>
				Save
				</button>
			</div>
			<?php } else { ?>
			<div class="btn-group" id="toolbar-apply">
				<button href="#" id="btn_update" data-action="update" class="btn btn-small btn-success save">
				<i class="icon-apply icon-white">
				</i>
				Update
				</button>
			</div>
			<?php } ?>

			<div class="btn-group" id="toolbar-cancel">
				<a href="index.php?option=com_j2store&view=coupons" class="btn btn-small">
				<i class="icon-cancel ">
				</i>
				Cancel
				</a>
			</div>
		</div>
	</div>
	<br>
	<br>
	<div class="alert alert-error" id="msg" style="width:25%;display:none;">Please fill all the fields..</div>



<?php $cpn_link = JRoute::_('index.php?option=com_j2store&view=coupon&task=save'); ?>

<?php if(isset($_REQUEST['id'])) 
	  {
	  	$id = $_REQUEST['id'];
		$db = JFactory::getDbo();	
		$query = "select * from `#__j2store_promocodes` where promocode_id =".$id;
		
		$db->setQuery($query);
		$result = $db->loadObjectList(); 
		$result = $result[0];
		
		$name = $result->name;
		$discount = $result->discount;
		$code = $result->code;
		$from = $result->from;
		$to = $result->to;
		$cpn_link = JRoute::_('index.php?option=com_j2store&view=coupon&task=update');
	  }

?>

<form action="<?php echo $cpn_link; ?>" method="post" id="cpn_new">

		<input type="hidden" id="cpn_id" name="cpn_id" value="<?php if(isset($id)){ echo $id; }  ?>">
	
	
		Coupon Name
		<input type="text" id="cpn_name" name="cpn_name" placeholder="Name" style="margin-left: 29px;margin-top: 20px;"
		value="<?php if(isset($name)){ echo $name; }  ?>">
		<br>
	    
		Coupon Discount
		<input type="text" id="cpn_disc" name="cpn_disc" placeholder="Discount" style="margin-left: 13px;margin-top: 20px;" onkeypress='return isNumberKey(event)' maxlength="4" value="<?php if(isset($discount)){ echo $discount; }  ?>">
		<br>
		
		Coupon code
		<input type="text" id="cpn_code" name="cpn_code" placeholder="Code" style="margin-left: 35px;margin-top: 20px;" 
		value="<?php if(isset($code)){ echo $code; }  ?>">
		
		
		<br>
		Valid From <input type="text" id="dp_from" name="dp_from" placeholder="valid from" style="margin-left: 50px;margin-top: 20px;"
		value="<?php if(isset($from)){ echo $from; }  ?>">

		<br>
		Valid To <input type="text" id="dp_to" name="dp_to" placeholder="valid to" style="margin-left: 65px;margin-top: 20px;"
		value="<?php if(isset($to)){ echo $to; }  ?>">

		
</form>
</div>

 <script>
jQuery(function() {

	jQuery( "#dp_from , #dp_to"  ).datepicker({
	 dateFormat: "yy-m-d",
	 minDate: '0',
	 onSelect:function(selectedDate)
	 {
	 	from = jQuery('#dp_from').val();
	 	to = jQuery('#dp_to').val();
	 	
	 	if(from != '' && to != '')
	 	{
		 	if(new Date(to) >= new Date(from))
			{	
			}
			else
			{
				alert('To date must be greater than From date');
				jQuery('#dp_to').val('');
			}
		}
	 	
	 }
	});

	jQuery('.save').click(function(){
		
		
		var name = jQuery('#cpn_name').val().trim();
		var discount = jQuery('#cpn_disc').val().trim();
		var code = jQuery('#cpn_code').val().trim();
		var from = jQuery('#dp_from').val().trim();
		var to =  jQuery('#dp_to').val().trim();
	
		var values = new Array(name,discount,code,from,to);
		err = 0;
	
		for(i=0;i<values.length;i++)
		{
			if(values[i].length == 0)
			{
				err= 1;
			}
		}
	
		if(jQuery(this).attr('data-action') == 'save')
		{
			if(err)
			{
				jQuery('#msg').show();
				return false;
			}
			else
			{
				jQuery('#msg').hide();
				jQuery.ajax({
				url: "index.php?option=com_j2store&view=coupon&task=checkduplicate",
				type: "POST",
				dataType : "json",
				data :{ code: code },
				success : function(data){
				   if(data.result == 1)
				   {
				   		jQuery('#msg').show();
						jQuery('#msg').html('Coupon code already exist.');
						return false;
				   }
				   else
				   {
					  jQuery('#cpn_new').submit();
				   }
				}		
			   });		  
			}
		}
		else
		{
			if(err)
			{
				jQuery('#msg').show();
				return false;
			}
			else
			{
				jQuery('#msg').hide();
			    jQuery('#cpn_new').submit();
			}
		}
	});
	
	jQuery('#cpn_disc').bind("cut copy paste",function(e) {
          e.preventDefault();
    });

	jQuery("#cpn_disc").bind("contextmenu", function(e) {
    e.preventDefault();
	});
});

function isNumberKey(evt){
    var charCode = (evt.which) ? evt.which : event.keyCode
    if (charCode > 31 && (charCode < 48 || charCode > 57))
        return false;
    return true;
}

</script>
