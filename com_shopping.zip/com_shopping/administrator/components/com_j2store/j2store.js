jQuery(document).ready(function() {
	jQuery('.cbx').click(function(){
		var id = jQuery(this).attr('data-val');	
		if(jQuery(this).prop('checked') == true)
		{
			jQuery('#allids').val(jQuery('#allids').val()+id+',');
		}
		else
		{
			var checkedid=jQuery('#allids').val();
			var uncheckedid=id+',';
			var rescheck=checkedid.replace(uncheckedid,'');
			jQuery('#allids').val(rescheck);
		}
	});
	
	jQuery('#selcbx').click(function(){
	
		allids = '';
		jQuery('.cbx').each(function(){
			if(jQuery('#selcbx').prop('checked') == true)
			{
				jQuery(this).prop('checked',true);
				allids = allids+jQuery(this).attr('data-val')+',';
			}
			else
			{
				jQuery(this).prop('checked',false);
			}
		});
		
		jQuery('#allids').val(allids);
	
	});
	
});
	
function delvalid(){

	if(jQuery('#allids').val().trim().length > 0)
	{
		return true;
	}
	else
	{
		alert('Please first make a selection from the list');
		return false;
	}
}
