jQuery(document).ready(function() {

	jQuery('.enquiry').click(function(){

	    invoice = jQuery(this).attr('data-value');
		jQuery.ajax({
			//url: "/components/com_j2store/enquiry.php",
			url: "index.php?option=com_j2store&view=orders&task=enquiry",
			type: "POST",
			dataType : "json",
			data :{ invoice:invoice,type:'enquiry' },
			success : function(data){
				if(data.result == 1)
				{
					jQuery('#enquirymsg').html('<button type="button" style="padding: 10px;" class="close" data-dismiss="alert">&times;</button><div class="alert alert-success">You will get a mail regarding order status. <b>Thank You...</b></div>');
				}
				else
				{
					jQuery('#enquirymsg').html('<button type="button" style="padding: 10px;" class="close" data-dismiss="alert">&times;</button><div class="alert alert-error">Sorry..! Order not found.</div>');
				}
			}		
		});
	});
});
	 
