<?php

define( '_JEXEC', 1 );

if (stristr( $_SERVER['SERVER_SOFTWARE'], 'win32' )) {

	define( 'JPATH_BASE', realpath(dirname(__FILE__).'\..\..\..\..' ));
} else define( 'JPATH_BASE', realpath(dirname(__FILE__).'/../..' ));

define( 'DS', DIRECTORY_SEPARATOR );


require_once ( JPATH_BASE.DS.'includes'.DS.'defines.php' );
require_once ( JPATH_BASE.DS.'includes'.DS.'framework.php' );
$app =& JFactory::getApplication('site');
$app->initialise();

jimport( 'joomla.plugin.plugin' );
jimport( 'joomla.user.user' );
jimport( 'joomla.user.helper');


?>

<?php

	$type =  $_POST['type'];

	if($type == 'enquiry')
	{
		$invoice = $_POST['invoice'];
		$date = date("Y-m-d H:i:s");
        $query = "Insert into  `#__j2store_orderenquiry`(`invoice`,`date`) values($invoice,'$date')"; 
        $db = &JFactory::getDBO();
        $db->setQuery($query);
        $result = $db->query();
  
  		echo json_encode(array('result'=>$result));	
  		exit;
	}
?>
